//
//  ProfileView.swift
//  StudyOn
//
//  Created by Minseok Chey on 5/31/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ProfileView()
}
