//
//  RootView.swift
//  StudyOn
//
//  Created by Minseok Chey on 5/30/24.
//

import SwiftUI

struct RootView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    RootView()
}
